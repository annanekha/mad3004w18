//: Playground - noun: a place where people can play

import UIKit

var str = "hai"

print("this is o/p: \(str)",terminator:  " "); //: use of terminator
print("1","2","3","4","5",separator:"..") //: use of separator for multiple promts
var n1=10,n2=20,n3=30
print("NUMBER 1 = ",n1)
print("NUMBER 2 = ",n2)
print("NUMBER 3 = ",n3)
var sum=n1+n2+n3;
print("SUM = ",sum)
print("sum = ", n1+n2+n3)
/*
n1 = 'test1'
print(n1)
*/

var a:Int = 10 // explicitly declaring variable type
print("a = ",a)

var greet:String = "Good Morning"
print("Greetings : ",greet)

var q=10.5
print("q = ",q)
/*
q="test2"
print("q = ",q) //error: cannot assign value of type 'String' to type 'Double'
 */
var p:Float = 12.789
print("Value of p = ",p)

var emoji = "😍"
print("ITS a \(emoji) hour")

let pi=3.14
//pi = 3.190
print(pi)
let mynum:Int? //optional
mynum = nil
if mynum != nil{
    print("mynum =",mynum!) //declared as optional,need to unwrap the mynum using !
}
else
{
print("mynum is nil")
}
let possiblenumber = "hello"
let convertednumber:Int?
convertednumber = Int(possiblenumber)
if convertednumber != nil{
    print("converted number =",convertednumber!) //declared as optional,need to unwrap the mynum using !
}
else
{
    print("coverted number is nil")
}
for i in 1..<5{
    print("i = ",i)
}
let languages:[String]                          //array string
languages=["English","French","Latin"]
for i in languages{                                          //array
    print("languages : ",i);
}

let arr:[Int]
arr = [1,34,56,89]
for i in arr{
//print(arr[i+1])}
    print("array elements is ",i)
}
var answer:Int = 1
for _ in 1...5
{
    answer *= 5;
}
print(answer)

let constB:Float = 3.1256
print(constB)

var interval:Int = 5
for i in stride(from: 0, to:50, by:interval)
{
    print(i," ",terminator: " ")
}
var j=1
while(j < 5)
{
    print("value of j is \(j)")
    j = j + 1;
}
j = 5
repeat{
    print("repeat : ",j)
    j = j + 2
}while(j<=10)

var k = 2,iv=1
/*if(k<5)
{
    while(iv<=10){
    print(k*iv)
        iv=iv+1
    }
    } */

var num1 = 10
switch num1{
case 100 :
    print("value of num1 is 100")
    //fallthrough
case 10,15 :
    print("value of num1 is 10")
case 30 :
    print("value of num1 is 30")
default :
    print("default case")
}

var no1 = 2
var i=1

if no1 > 5 {
    print("The number is greater than 10")
    repeat
    {   print("value = 5 * ", i ," = " , 5 * i )
        i = i + 1
    } while i <= 10

}
    
else {
    var j = 5
    var t = 1
    print("The number is less than 10")
    print("factorial of 5 is :",terminator: " ")
    repeat
    {   t = t * j
        j = j - 1
    } while j > 0
    print(t)
}
