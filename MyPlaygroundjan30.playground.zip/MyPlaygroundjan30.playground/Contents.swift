//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"
//print(str)

//DISPLAYING MULTIPLE STRINGS

let strOne = """
This is first line
This is another line
This is one more line
Ok. Enough of lines
"""

print(strOne)

//CHECKING IF STRING IS EMPTY
var mood = ""
let heart = "\u{1F496}"
mood = "happy"
if mood.isEmpty {
    print("cheer up")
}
else{
    print(heart)
}
mood += " cheerful joyful "
print(mood)

//heart += " Be happy "
print(heart)

var firstname = String()
var lastname = String()
//lastname = "Shabu "
firstname = "AnnaNekha"
print(firstname)

for i in firstname {
    print(i)
}

//appending character
let initial : Character = "A"
firstname.append(initial)

//finding the length of string
print(firstname)
print("firstname is \(firstname) which is \(firstname.count) characters long. ")

//finding start index
print("Start index : ",firstname[firstname.startIndex])
//finding end idex
//print("End index : ",firstname[firstname.endIndex])
//finding character before end index
print("before end index : ", firstname[firstname.index(before: firstname.endIndex)])
//finding character start end index
print("after start index : ", firstname[firstname.index(after: firstname.startIndex)])
//finding 5th character
print("5th character: ", firstname[firstname.index(firstname.startIndex,offsetBy: 4)])
//finding 3rd character from last
print("3rd from last character: ", firstname[firstname.index(firstname.endIndex,offsetBy: -3)])
//finding fourth character
var idx = firstname.index(firstname.startIndex,offsetBy: 3)
print("fourth character:", firstname[idx])



var language = "Swift"
print("Language : ",language)

language.insert("!",at: language.endIndex)
print("Language : ",language)

language.insert(contentsOf:"java",at:language.endIndex)
print("Language : ",language)

language.insert(contentsOf: " is nicer than ",at: language.index(language.startIndex,offsetBy: 6))
print("Language contentsOf: ",language)

language.remove(at: language.index(before: language.endIndex))
print("language remove : ",language)

let range = language.startIndex..<language.endIndex
language.removeSubrange(range)

print("language removeSubrange : ",language)


//printing the string in reverse order
var name :String = "nekha"
print(name.count)
var count_name: Int = name.count


print (name[name.startIndex])
var i :Character

var limit = Int(name.count)
var j :Int = 0



j = limit-1
while( j >= 0) {
    i = name[name.index(name.startIndex,offsetBy: j)]
    print("\n",i)
    j = j-1
    
}
j = 0
while( j <= limit) {
    i = name[name.index(name.startIndex,offsetBy: j)]
    print("\n",i)
    j = j+1
    
}
