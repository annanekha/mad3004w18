//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// creating a dictionary object
//var person = [String: AnyObject]()
//let address = [String : String]()
//person["firstName"] = "Anna Nekha" as AnyObject
//person["lastName"] = "Shabu" as AnyObject
//person["age"] = Int(22) as AnyObject
//person["address"] = ["street" : "50 Trudelle St", "area" : "Scarborough", "postalCode" : "M1J1Z3"] as AnyObject
//person["total amount"] = Double(2000) as AnyObject
//print("person: ",person)

//closure in swift

// closure expression syntax
/*
 {
 (parameters) -> return type in(if not in a fn use in keyword)
 statements
 }
 */

//sorted closure
var months = [4,3,1,6,5,2]
print("Months sorted : ",months.sorted())

//reversed closure
func reverse(_ s1: Int, _ s2: Int) -> Bool{
    return s1 > s2
}

var reversedMonths = months.sorted(by: reverse)
print("Reversed Months : ",reversedMonths)

//increasing closure
func increasing(_ s1: Int, _ s2: Int) -> Bool{
    return s1 < s2
}
var IncreasingMonths = months.sorted(by: increasing)
print("Increasing Months : ",IncreasingMonths)


// CLOSURE DECLARATION
var reverseClosure = months.sorted(by: {
    (s1: Int, s2: Int) -> Bool in
    return s1 > s2
})
print("Reverse Closure",reverseClosure)

//INFERRING Parameter types from context

var inferTypes = months.sorted(by: {
/*
 any of these
 (s1, s2) in return s1 < s2
    //(s1, s2) in s1 < s2 //implicit return
 
    // (s1,s2) in return s1 < s2
 */
    
   (s1, s2) in s1 < s2 //implicit return
})
print("Infer Types",inferTypes)

//shorthand ARGUMENT NAMES
print("shorthand ARGUMENT NAMES : ", months.sorted(by: {$0 < $1}))

//operator methods
print("Operator methods : ", months.sorted(by: < ))

var three = [1,2,3,4,5,6,7,8,9,12,15]
print("Three : ",three)

var modThree =  three.filter({$0 % 3 == 0 })
print("Modulus Three : ", modThree)

var even =  three.filter({$0 % 2 == 0 })
print("Even Numbers : ", even)


//nested functions closure

func makeIncrementer(forIncrement amount: Int) -> () -> Int
{
var runningTotal = 0

    func incrementer() -> Int {
        runningTotal += amount
        return runningTotal
    }
 return incrementer
}
let incrementByTen = makeIncrementer(forIncrement: 10)

print("First Call : ",incrementByTen())
// returns a value of 10
print("Second Call : ",incrementByTen())
// returns a value of 20
print("Third Call : ",incrementByTen())
// returns a value of 30
let incrementBySeven = makeIncrementer(forIncrement: 7)

print("Increment by Seven 1 :",incrementBySeven()) //7
print("Increment by Seven 2 :",incrementBySeven()) //14

print("Fourth Call : ",incrementByTen()) //40

//closures are reference type
let incrementBySevenAgain = incrementBySeven
print("Increment by Seven 3 :",incrementBySeven())

//auto closure
var errorList = [404,414,402,431,455,440]
print("Total Errors : ", errorList.count)

let debugger = {errorList.remove(at: 0)}
print("Total Errors : ", errorList.count)

print("Now Solving \(debugger())!") //invoking auto closure
print("Total Errors : ", errorList.count)
print("Error List : ", errorList)

func solve(error debugger: @autoclosure () -> Int) {
    print("Now solving \(debugger())!")
}

solve(error: errorList.remove(at: 0))
print("Error List: ", errorList)

/*
 read about escaping closures & trailing closure
 and try them */





