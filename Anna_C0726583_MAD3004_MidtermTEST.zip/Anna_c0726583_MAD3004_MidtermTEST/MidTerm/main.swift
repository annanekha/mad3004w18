//
//  main.swift
//  MidTerm
//
//  Created by Anna Nekha Shabu on 2018-02-07.
//  Copyright © 2018 Anna Nekha Shabu. All rights reserved.
//

import Foundation

print("******Sports******")

var objs1 = Sports()
objs1.displays()

var objs2 = Sports(stype: "Outdoor",nop: 11)
objs2.displays()

print("******Cricket******")

var objc1 = Cricket(stype: "Outdoor", nop: 11, format: "One Day", no_overs: 20, wickets: 5, t_runs: 145, p_overs: 10)
objc1.IDisplay()
objc1.update()
objc1.displays()

var objc2 = Cricket(stype: "Outdoor", nop: 11, format: "Test Match", no_overs: 50, wickets: 7, t_runs: 356, p_overs: 34)
objc2.IDisplay()
objc2.update()
objc2.displays()

print("******Football******")

var objf3 = Football(stype: "Outdoor", nop: 11, no_mins: 90, nom_played: 86, no_goals: 2, tot_redcards: 3, p_time: 15, p_shootout: 1)
objf3.displays()
objf3.updategoals()
objf3.IDisplay()


var objf4 = Football(stype: "Outdoor", nop: 11, no_mins: 90, nom_played: 90, no_goals: 3, tot_redcards: 4, p_time: 15, p_shootout: 0)
objf4.displays()
objf4.updategoals()
objf4.IDisplay()



