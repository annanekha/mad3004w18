//
//  IDisplay.swift
//  Final_Project
//
//  Created by Anna Nekha Shabu on 2018-02-12.
//  Copyright © 2018 Anna Nekha Shabu. All rights reserved.
//

import Foundation

protocol IDisplay
{
    func displayData() -> String
}
