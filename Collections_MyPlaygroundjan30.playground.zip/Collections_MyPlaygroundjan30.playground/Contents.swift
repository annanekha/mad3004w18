//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//array collection
var a = [10, 20, 30, 40, 50]
print("a[0] : \(a[0])")
print("a: ",a)

let j1 = [10,20]
print("j1 : ",j1)

//use methods to add values
var b = [Int]();
print("size of array b : \(b.count)")
b.append(1000)
print("b[0]",b[0])

b.append(1000)
print("b : ",b)

b[0] = 1000
print("b[0]",b[0])

/* index out of range
 b[2]=500
 print("b : ", b)
 print("size of array b : \(b.count)")
 */

//assigning the default value
var num1 = [Int](repeating: 1,count: 3)
print("num1 array",num1)

var num2 = [Int](repeating: 5,count: 3)
print("num1 array",num2)

var numMerge = num1 + num2
print("Merged array",numMerge)

//declare to store any data type values

var c = [Any]();
print("size of array c : \(c.count)")
c.append(1000)
print("c[0]",c[0])
c.append("patel")
c.append(12.89)
print("C array : ",c)

//using an array contents
var x = a[1...3]
for t in x{
    print("x : \(t)")
}

//String array and for-each with (key, value)
var shoppingList: [String] = ["EGGS","MILK"]
for (index,value) in shoppingList.enumerated(){
print("Item \(index): \(value)")
}

print("The shopping list contains \(shoppingList.count) items.")

if shoppingList.isEmpty{
    print("The shopping list is empty.")
}
else{
    print("The shopping list is not empty.")
}

shoppingList.append("Flour")
print("ShoppingList array : \(shoppingList)")

shoppingList += ["chocolate spread","cheese","butter"]
print("ShoppingList array : \(shoppingList)")

shoppingList.insert("Maple Syrup", at:0)
print("ShoppingList array : \(shoppingList)")

let mapleSyrup = shoppingList.remove(at: 2)
let apples = shoppingList.removeLast()

print("ShoppingList array : \(shoppingList)")

//combine two arrays
//using + operator

//set
//declaring set

var grades: Set<Character> = []

//use set name.count

grades.insert("A")
grades.insert("B")

print("grades : ",grades)
print("grade no of elements",grades.count)

/* no duplicate values
 require hashables
 convert elemts to hash values so wont let to do it
 hashable datatypes are int,double ,char,boolean
******** var gradeType: Set <Any> = [] **************
 */

var favouriteGenres: Set<String> = ["rock","classical","hip hop"]
print("favourite Genres",favouriteGenres)

print("I have ",favouriteGenres,"in my collection")

if favouriteGenres.isEmpty{
    print("am not picky")
}
else{
    print("i have particular preferances")
}

favouriteGenres.insert("jazz")
print("favourite Genres",favouriteGenres)

if let removedGenre = favouriteGenres.remove("rock")
{
    print("\(removedGenre)? i'm over it.")
}
else
{
    print("i never cared much for that.")
}

print("favourite Genres",favouriteGenres)

for genre in favouriteGenres.sorted()
{
    print("\(genre)")
}


let od: Set = [1,3,5,7,9]
let ed: Set = [0,2,4,6,8]
let sdpn: Set = [2,3,5,7]

print(od.union(ed).sorted())
print(od.intersection(ed).sorted())
print(od.subtracting(sdpn).sorted())
print(od.symmetricDifference(sdpn).sorted())

let houseAnimals: Set = ["🐶", "🐱","🐷"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]

print(houseAnimals.isSubset(of: farmAnimals))
print(farmAnimals.isSuperset(of: houseAnimals))
print(farmAnimals.isDisjoint(with: cityAnimals))

