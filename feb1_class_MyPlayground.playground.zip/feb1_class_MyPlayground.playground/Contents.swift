//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//classes and structures in swift

// declaring a structure
struct project{
    var title = ""
    var hours = 0
    
    
    func display()
    {
        print("Project title :", title)
        print("Total Work hours required :", hours)
    }
}

//DECLARING AN INSTANCE FOR structure
var LMSProject = project(title: "Moodle", hours: 200)
print(LMSProject)

LMSProject.display()

LMSProject.hours = 300
LMSProject.display()

//class declaration

class Manager{
    var name: String = ""
    var productOwner : Bool = true
    var currentProjects = project()
}

//creating instance for class
let mgrCanada = Manager()
mgrCanada.name = "Anna"
mgrCanada.productOwner = true
mgrCanada.currentProjects = project(title: "Sales Reporting",hours :20)

print("Name",mgrCanada.name)
print("Product Owner",mgrCanada.productOwner)
print("Project Title",mgrCanada.currentProjects.title) //invoking structure members
print("Hours",mgrCanada.currentProjects.hours)  //invoking structure members

//changing properties
mgrCanada.productOwner = false
mgrCanada.currentProjects = project(title: "Sales Reporting",hours :500)

print("Name",mgrCanada.name)
print("Product Owner",mgrCanada.productOwner)
print("Project Title",mgrCanada.currentProjects.title) //invoking structure members
print("Hours",mgrCanada.currentProjects.hours)  //invoking structure members


//structure value types
struct address{
    var street = "265 Yorkland Blvd"
    var city = "North York"
    var postalcode = "M1H1Y1"
}

var lambton = address()
print("Lambton : ", lambton)

var cestar = lambton
//let cestar = lambton
//raise error when change the parameter
print("Cestar : ",cestar)

cestar.street = "271 Yorkland Blvd"
cestar.postalcode = "M1H3Y3"
print("Cestar : ", cestar)

print("Lambton : ", lambton)

//classes are ** REFERENCE TYPES **
class Institute{
    var street = "265 Yorkland Blvd"
    var city = "North York"
    var postalcode = "M1H1Y1"
}

var myLambton = Institute()
print("Street : ",myLambton.street)
print("City : ",myLambton.city)
print("Postal Code : ",myLambton.postalcode)

var mycestar = myLambton
print("mycestar Street : ",mycestar.street)
print("mycestar City : ",mycestar.city)
print("mycestar Postal Code : ",mycestar.postalcode)

mycestar.street = "271 Yorkland Blvd"
mycestar.postalcode = "M1H3Y3"

print("mycestar Street : ",mycestar.street)
print("mycestar Postal Code : ",mycestar.postalcode) //same values

print("mycestar Street : ",mycestar.street)
print("mycestar Postal Code : ",mycestar.postalcode) // same values


//identical to ===
if myLambton === mycestar {
    print("LAMBTON AND CESTAR ARE SAME")
}
else {
    print("LAMBTON AND CESTAR ARE  NOT SAME")
}

var yourCestar = Institute()
if yourCestar === mycestar {
    print("LAMBTON AND CESTAR ARE SAME")
}
else {
    print("LAMBTON AND CESTAR ARE NOT SAME")
}

//task for today

class person{
    var first_name = "Anna"
    var last_name = "Shabu"
    var age = 20
    var total_amount = 2000
    var loc = address() //invoking structure data

}

var personP = person() //initializing class
print("First Name : ", personP.first_name)
print("Last Name : ", personP.last_name)
print("Age : ", personP.age)
print("Total Amount : ", personP.total_amount)
print("Street : ", personP.loc.street)
print("City : ", personP.loc.city)
print("Postal Code : ", personP.loc.postalcode)














